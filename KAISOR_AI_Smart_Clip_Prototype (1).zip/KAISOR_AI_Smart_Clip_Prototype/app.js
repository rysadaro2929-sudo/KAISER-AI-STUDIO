(function () {
  "use strict";
  const $ = id => document.getElementById(id);
  const input = $("videoInput"), video = $("sourceVideo");
  let objectUrl = null, analysis = null, clips = [];

  function formatTime(seconds) {
    const s = Math.max(0, Math.floor(seconds));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }
  function setProgress(percent, label) {
    $("progressWrap").classList.remove("hidden");
    $("progressBar").style.width = `${percent}%`;
    $("progressPercent").textContent = `${percent}%`;
    $("progressText").textContent = label;
  }
  function resetResults() {
    analysis = null; clips = [];
    $("resultsPanel").classList.add("hidden");
    $("exportPanel").classList.add("hidden");
  }

  input.addEventListener("change", () => {
    const file = input.files && input.files[0];
    if (!file) return;
    if (!file.type.startsWith("video/")) { alert("សូមជ្រើសរើសឯកសារវីដេអូ។"); return; }
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(file);
    video.src = objectUrl;
    $("fileName").textContent = file.name;
    $("videoMeta").textContent = "កំពុងអានព័ត៌មានវីដេអូ...";
    $("sourceInfo").classList.remove("hidden");
    $("uploadZone").classList.add("hidden");
    $("analyzeBtn").disabled = true;
    resetResults();
  });

  video.addEventListener("loadedmetadata", () => {
    $("videoMeta").textContent = `${video.videoWidth} × ${video.videoHeight} · ${formatTime(video.duration)}`;
    $("analyzeBtn").disabled = false;
  });
  video.addEventListener("error", () => {
    $("videoMeta").textContent = "មិនអាចបើកទម្រង់វីដេអូនេះបានទេ";
    $("analyzeBtn").disabled = true;
  });

  $("removeVideo").addEventListener("click", () => {
    video.pause(); video.removeAttribute("src"); video.load();
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = null; input.value = "";
    $("sourceInfo").classList.add("hidden");
    $("uploadZone").classList.remove("hidden");
    $("analyzeBtn").disabled = true;
    $("progressWrap").classList.add("hidden");
    resetResults();
  });

  function renderClips() {
    const list = $("clipsList");
    list.innerHTML = "";
    clips.forEach((clip, index) => {
      const row = document.createElement("label");
      row.className = "clip-card";
      const check = document.createElement("input");
      check.type = "checkbox"; check.checked = clip.selected !== false;
      check.addEventListener("change", () => { clip.selected = check.checked; updateSummary(); });
      const main = document.createElement("div"); main.className = "clip-main";
      const title = document.createElement("div"); title.className = "clip-title";
      title.textContent = `HIGHLIGHT ${String(index + 1).padStart(2, "0")} · ${formatTime(clip.start)} – ${formatTime(clip.end)}`;
      const meta = document.createElement("div"); meta.className = "clip-meta";
      meta.textContent = `${(clip.end - clip.start).toFixed(1)}s · ${clip.reason || "Local visual analysis"}`;
      const score = document.createElement("div"); score.className = "clip-score"; score.textContent = `${clip.score}/100`;
      main.append(title, meta); row.append(check, main, score); list.appendChild(row);
    });
    updateSummary();
  }

  function updateSummary() {
    const selected = clips.filter(c => c.selected !== false);
    $("clipCount").textContent = selected.length;
    $("totalDuration").textContent = `${Math.round(selected.reduce((n,c) => n + c.end - c.start, 0))}s`;
  }

  $("analyzeBtn").addEventListener("click", async () => {
    if (!video.src || !Number.isFinite(video.duration)) return;
    $("analyzeBtn").disabled = true;
    $("resultsPanel").classList.add("hidden");
    try {
      setProgress(0, "ចាប់ផ្ដើម Local AI analysis...");
      analysis = await window.KAISORAI.analyzeVideo(video, {
        sensitivity: $("sensitivity").value,
        sampleEvery: 1.25,
        maxSamples: 240
      }, setProgress);

      let candidates = analysis.scenes;
      let mode = "LOCAL";
      const endpoint = $("cloudEndpoint").value.trim();
      if (endpoint) {
        try {
          setProgress(88, "កំពុងស្នើ Cloud AI វាយតម្លៃ Keyframes...");
          const cloud = await window.KAISORAI.enhanceWithCloud(endpoint, analysis, {
            duration: video.duration, width: video.videoWidth, height: video.videoHeight
          });
          if (cloud && cloud.length) { candidates = cloud; mode = "HYBRID"; }
        } catch (cloudError) {
          console.warn("Cloud AI unavailable; using local ranking:", cloudError);
          alert(`Cloud AI មិនអាចប្រើបាន៖ ${cloudError.message}\nកម្មវិធីនឹងបន្តដោយ Local Analysis។`);
        }
      }
      const target = Number($("targetDuration").value);
      clips = window.KAISORAI.chooseHighlights(candidates, target);
      if (!clips.length) throw new Error("មិនអាចរកឃើញឈុតសមស្របទេ។ សូមសាកល្បងវីដេអូផ្សេង ឬប្ដូរ Sensitivity។");
      $("analysisMode").textContent = mode;
      $("resultsPanel").classList.remove("hidden");
      renderClips();
      setProgress(100, "ការវិភាគរួចរាល់");
    } catch (err) {
      alert(err.message || "មានបញ្ហាក្នុងការវិភាគវីដេអូ។");
    } finally {
      $("analyzeBtn").disabled = false;
    }
  });

  $("selectAllBtn").addEventListener("click", () => {
    const allSelected = clips.every(c => c.selected !== false);
    clips.forEach(c => c.selected = !allSelected);
    renderClips();
    $("selectAllBtn").textContent = allSelected ? "ជ្រើសរើសទាំងអស់" : "ដកជម្រើសទាំងអស់";
  });

  $("exportBtn").addEventListener("click", async () => {
    const selected = clips.filter(c => c.selected !== false).sort((a,b) => a.start - b.start);
    if (!selected.length) { alert("សូមជ្រើសរើសយ៉ាងហោចណាស់មួយឈុត។"); return; }
    $("exportPanel").classList.remove("hidden");
    $("downloadLink").classList.add("hidden");
    $("renderProgress").style.width = "0%";
    $("renderStatus").textContent = "កំពុងចាប់ផ្ដើម Render...";
    $("exportBtn").disabled = true;
    try {
      const blob = await window.KAISORExport.exportClips(video, selected, $("aspectRatio").value, (p, label) => {
        $("renderProgress").style.width = `${p}%`;
        $("renderStatus").textContent = `${label} · ${p}%`;
      });
      const url = URL.createObjectURL(blob);
      const link = $("downloadLink");
      if (link.dataset.url) URL.revokeObjectURL(link.dataset.url);
      link.dataset.url = url;
      link.href = url;
      link.download = "KAISOR-AI-Smart-Clip.webm";
      link.classList.remove("hidden");
      $("renderStatus").textContent = `រួចរាល់ · ${(blob.size / 1024 / 1024).toFixed(1)} MB · WebM`;
    } catch (err) {
      $("renderStatus").textContent = `Export បរាជ័យ៖ ${err.message}`;
      alert(`Export មិនបានសម្រេច៖ ${err.message}`);
    } finally {
      $("exportBtn").disabled = false;
    }
  });

  window.addEventListener("beforeunload", () => {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    const link = $("downloadLink");
    if (link.dataset.url) URL.revokeObjectURL(link.dataset.url);
  });
})();
