/* Browser-side WebM renderer. Support depends on the Android browser. */
(function (global) {
  "use strict";

  function supportedMime() {
    const choices = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
    return choices.find(type => window.MediaRecorder && MediaRecorder.isTypeSupported(type)) || "";
  }

  function seek(video, time) {
    return new Promise((resolve, reject) => {
      if (Math.abs(video.currentTime - time) < 0.05) return resolve();
      const ok = () => { clean(); resolve(); };
      const fail = () => { clean(); reject(new Error("មិនអាច seek វីដេអូសម្រាប់ Export បានទេ។")); };
      const clean = () => {
        video.removeEventListener("seeked", ok);
        video.removeEventListener("error", fail);
      };
      video.addEventListener("seeked", ok, { once: true });
      video.addEventListener("error", fail, { once: true });
      video.currentTime = time;
    });
  }

  async function exportClips(video, clips, aspectRatio, onProgress) {
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
      throw new Error("Browser នេះមិនគាំទ្រ MediaRecorder/Canvas Capture ទេ។ សូមសាកល្បង Chrome ជំនាន់ថ្មី។");
    }
    if (!clips.length) throw new Error("មិនមានឈុតដែលបានជ្រើសរើសទេ។");

    const sourceW = video.videoWidth || 1280;
    const sourceH = video.videoHeight || 720;
    let width = sourceW, height = sourceH;
    if (aspectRatio === "9:16") { width = 720; height = 1280; }
    else if (aspectRatio === "16:9") { width = 1280; height = 720; }
    else if (aspectRatio === "1:1") { width = 900; height = 900; }
    else {
      const scale = Math.min(1, 1280 / Math.max(sourceW, sourceH));
      width = Math.max(2, Math.round(sourceW * scale / 2) * 2);
      height = Math.max(2, Math.round(sourceH * scale / 2) * 2);
    }

    const canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    const ctx = canvas.getContext("2d");
    const canvasStream = canvas.captureStream(30);
    let audioTracks = [];
    try {
      const capture = video.captureStream ? video.captureStream() : (video.mozCaptureStream ? video.mozCaptureStream() : null);
      if (capture) audioTracks = capture.getAudioTracks();
    } catch (_) {}
    const stream = new MediaStream([...canvasStream.getVideoTracks(), ...audioTracks]);
    const mimeType = supportedMime();
    if (!mimeType) throw new Error("Browser មិនមាន WebM encoder ដែលគាំទ្រទេ។");
    const chunks = [];
    const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 5000000 });
    recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };

    const finished = new Promise((resolve, reject) => {
      recorder.onerror = () => reject(new Error("MediaRecorder មានបញ្ហាក្នុងការនាំចេញ។"));
      recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType }));
    });

    function drawFrame() {
      const sw = video.videoWidth || width, sh = video.videoHeight || height;
      const scale = Math.max(width / sw, height / sh);
      const dw = sw * scale, dh = sh * scale;
      const dx = (width - dw) / 2, dy = (height - dh) / 2;
      ctx.fillStyle = "#000"; ctx.fillRect(0, 0, width, height);
      ctx.drawImage(video, dx, dy, dw, dh);
    }

    recorder.start(500);
    try {
      for (let i = 0; i < clips.length; i++) {
        const clip = clips[i];
        await seek(video, clip.start);
        video.muted = false;
        await video.play();
        const startClock = performance.now();
        const durationMs = Math.max(500, (clip.end - clip.start) * 1000);
        await new Promise((resolve, reject) => {
          let raf;
          const tick = () => {
            if (video.error) { cancelAnimationFrame(raf); reject(new Error("Video playback error during export.")); return; }
            drawFrame();
            const elapsed = performance.now() - startClock;
            if (onProgress) onProgress(Math.min(99, Math.round(((i + Math.min(1, elapsed / durationMs)) / clips.length) * 100)), `កំពុង Render ឈុត ${i+1}/${clips.length}`);
            if (elapsed >= durationMs || video.ended) {
              video.pause(); cancelAnimationFrame(raf); resolve();
            } else raf = requestAnimationFrame(tick);
          };
          raf = requestAnimationFrame(tick);
        });
      }
    } catch (err) {
      recorder.stop();
      try { await finished; } catch (_) {}
      stream.getTracks().forEach(t => t.stop());
      throw err;
    }
    recorder.stop();
    const blob = await finished;
    stream.getTracks().forEach(t => t.stop());
    if (onProgress) onProgress(100, "Export រួចរាល់");
    return blob;
  }

  global.KAISORExport = { exportClips };
})(window);
