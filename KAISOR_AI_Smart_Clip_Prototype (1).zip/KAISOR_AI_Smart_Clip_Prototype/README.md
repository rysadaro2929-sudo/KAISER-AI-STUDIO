# KAISOR AI Smart Clip — Prototype 01

This is an isolated proof-of-concept for the KAISOR AI Smart Clip feature. It does **not** replace or modify the existing KAISOR Video Editor V6.4 files.

## Files
- `index.html` — prototype interface
- `style.css` — interface styles
- `app.js` — UI and workflow
- `ai-engine.js` — local frame analysis and optional cloud adapter
- `export.js` — browser WebM rendering/export

## Run in Acode / Android
1. Extract the ZIP into a new folder.
2. Open `index.html` in Acode preview or a modern browser.
3. Choose a video file.
4. Select a target duration and press **វិភាគ និងបង្កើត Smart Clips**.
5. Review/uncheck clips as needed, then press **នាំចេញវីដេអូ**.
6. Download the generated WebM file.

For best compatibility, use a current Chrome-based browser. Browser support for local video decoding, `MediaRecorder`, canvas capture, and audio capture varies by device. Export is WebM in this prototype.

## Important AI limitations
The local engine currently uses frame sampling, scene-change detection, image difference, and visual-motion/detail heuristics. This is a useful automatic highlight **prototype**, but it does not truly understand story meaning, speech, jokes, emotion, or the user's intent. Scores are heuristic estimates, not guaranteed quality judgments.

## Optional Cloud AI contract
Enter a trusted backend endpoint in the Cloud AI Endpoint field. The browser sends a JSON POST request:

```json
{
  "task": "rank_video_highlights",
  "video": { "duration": 120, "width": 1920, "height": 1080 },
  "candidates": [
    {
      "id": "local-1",
      "start": 0,
      "end": 8,
      "local_score": 72,
      "thumbnail_jpeg_data_url": "data:image/jpeg;base64,..."
    }
  ]
}
```

Expected response:

```json
{
  "highlights": [
    { "id": "local-1", "score": 94, "reason": "Main subject action and clear visual moment" }
  ]
}
```

The endpoint must be implemented on a server that performs vision-model analysis, allows the browser origin through CORS, validates uploads/payload sizes, and keeps all provider API keys server-side. Do not put secret API keys in `app.js`, HTML, or browser storage. The current adapter sends sampled thumbnail images, not the entire original video or its audio.

## Integration into V6.4
Do not overwrite the existing five production files with this prototype. First review the actual V6.4 source. Then integrate the engine and export adapter into the existing architecture with the smallest safe changes, preserving the current import, timeline, preview, and export workflows.
